package com.kitty.modder

import android.animation.ValueAnimator
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.Random
import kotlin.math.sin

class MainActivity : Activity() {
    private val PINK_BG = 0xFFFFC2E2.toInt()
    private val PINK_BTN = 0xFFFF8FC7.toInt()
    private val DARK = 0xFF4A0F2F.toInt()
    private val MAGENTA = 0xFF8B1A5A.toInt()

    private var apkUri: Uri? = null
    private var libUri: Uri? = null
    private var apkName = ""
    private var libName = ""
    private lateinit var apkText: TextView
    private lateinit var libText: TextView
    private lateinit var logText: TextView
    private lateinit var patchBox: CheckBox
    private lateinit var goBtn: Button
    private lateinit var content: LinearLayout
    private val cats = ArrayList<PixelCatView>()

    private var processing = false
    private var musicOn = false
    private var player: MediaPlayer? = null
    private var fx: ValueAnimator? = null
    private var bob: ValueAnimator? = null

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(PINK_BG))
        val pad = dp(16f).toInt()
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun add(v: View, topMargin: Float = 8f) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(topMargin).toInt()
            content.addView(v, lp)
        }

        add(catRow(0), 0)
        add(label("KITTY", 40f, bold = true).apply { gravity = android.view.Gravity.CENTER }, 4)
        add(label("~ lib mod injector ~", 14f).apply { gravity = android.view.Gravity.CENTER }, 0)

        add(pixelButton("1. Select APK") { pick(1) }, 16)
        apkText = label("No APK selected", 14f); add(apkText, 4)
        add(pixelButton("2. Select lib mod (.so)") { pick(2) }, 12)
        libText = label("No lib selected", 14f); add(libText, 4)
        patchBox = CheckBox(this).apply {
            text = "Patch DEX so the game loads the lib"
            isChecked = true; setTextColor(DARK); typeface = Typeface.MONOSPACE
        }
        add(patchBox, 12)
        goBtn = pixelButton("ACTIVATE") { activate() }.apply { textSize = 22f }
        add(goBtn, 12)
        logText = label("", 13f); add(logText, 12)
        add(catRow(2), 16)

        setContentView(ScrollView(this).apply { addView(content) })
        startBob()
    }

    // ---------- style helpers ----------

    private fun label(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(if (bold) MAGENTA else DARK)
        typeface = if (bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
    }

    private fun pixelButton(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(DARK)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        background = GradientDrawable().apply {
            setColor(PINK_BTN); setStroke(dp(3f).toInt(), MAGENTA); cornerRadius = 0f
        }
        setOnClickListener { onClick() }
    }

    private fun catRow(offset: Int): LinearLayout {
        val colors = intArrayOf(0xFFFFF4E6.toInt(), 0xFFFFB86B.toInt(), 0xFFBFB8D6.toInt(), 0xFFE3C4FF.toInt())
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until 4) {
            val cat = PixelCatView(this, colors[(i + offset) % 4], i + offset)
            cats.add(cat)
            row.addView(cat, LinearLayout.LayoutParams(0, dp(56f).toInt(), 1f))
        }
        return row
    }

    private fun startBob() {
        bob = ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat()).apply {
            duration = 1600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener {
                val t = it.animatedValue as Float
                cats.forEachIndexed { i, c -> c.translationY = sin(t + i * 0.8f) * dp(4f) }
            }
            start()
        }
    }

    // ---------- Activate effects: shake + rainbow + music ----------

    private fun startFx() {
        stopFx()
        val rnd = Random()
        fx = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1500; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener {
                val h = it.animatedValue as Float
                window.setBackgroundDrawable(ColorDrawable(Color.HSVToColor(floatArrayOf(h, 0.45f, 1f))))
                cats.forEachIndexed { i, c -> c.tint(Color.HSVToColor(floatArrayOf((h + i * 45f) % 360f, 0.5f, 1f))) }
                content.translationX = (rnd.nextFloat() - 0.5f) * 2f * dp(10f)
                content.translationY = (rnd.nextFloat() - 0.5f) * 2f * dp(10f)
                content.rotation = (rnd.nextFloat() - 0.5f) * 3f
            }
            start()
        }
    }

    private fun stopFx() {
        fx?.cancel(); fx = null
        content.translationX = 0f; content.translationY = 0f; content.rotation = 0f
        window.setBackgroundDrawable(ColorDrawable(PINK_BG))
        cats.forEach { it.tint(0) }
    }

    private fun maybeStopFx() { if (!processing && !musicOn) stopFx() }

    private fun startMusic() {
        try {
            player?.release()
            player = MediaPlayer.create(this, R.raw.kitty_music)?.apply {
                setOnCompletionListener { mp ->
                    mp.release(); player = null; musicOn = false; maybeStopFx()
                }
                start()
            }
            musicOn = player != null
        } catch (t: Throwable) {
            musicOn = false
        }
    }

    override fun onDestroy() {
        fx?.cancel(); bob?.cancel(); player?.release(); player = null
        super.onDestroy()
    }

    // ---------- picking files ----------

    private fun pick(code: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, code)
    }

    @Deprecated("simple picker")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        val name = queryName(uri)
        if (req == 1) { apkUri = uri; apkName = name; apkText.text = name }
        else { libUri = uri; libName = name; libText.text = name }
    }

    private fun queryName(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else null
        } ?: "file"

    private fun log(s: String) = runOnUiThread { logText.append(s + "\n") }

    private fun copyUri(uri: Uri, dst: File) {
        contentResolver.openInputStream(uri)!!.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
    }

    // ---------- the actual work ----------

    private fun activate() {
        val a = apkUri; val l = libUri
        if (a == null || l == null) { logText.text = "Pick an APK and a .so first.\n"; return }
        if (!libName.endsWith(".so")) { logText.text = "The lib must be a .so file.\n"; return }
        goBtn.isEnabled = false
        logText.text = ""
        processing = true
        startMusic()
        startFx()
        Thread {
            val work = File(cacheDir, "work").apply { deleteRecursively(); mkdirs() }
            try {
                log("Copying files...")
                val inApk = File(work, "in.apk"); copyUri(a, inApk)
                val inLib = File(work, "mod.so"); copyUri(l, inLib)
                val entry = if (libName.startsWith("lib")) libName else "lib$libName"
                val signed = Patcher.patch(inApk, inLib, entry, patchBox.isChecked, work, assets.open("kitty.p12")) { log(it) }
                val outName = apkName.removeSuffix(".apk") + "_kitty.apk"
                save(signed, outName)
                log("Done! Saved to Downloads/$outName")
            } catch (t: Throwable) {
                log("Failed: ${t.message ?: t.toString()}")
            } finally {
                work.deleteRecursively()
                runOnUiThread { processing = false; goBtn.isEnabled = true; maybeStopFx() }
            }
        }.start()
    }

    private fun save(src: File, name: String) {
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("Couldn't create file in Downloads")
            contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
        } else {
            val dir = getExternalFilesDir(null)!!
            src.copyTo(File(dir, name), overwrite = true)
        }
    }
}
