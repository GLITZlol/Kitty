package com.kitty.modder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** A tiny 2D pixel-art cat face, drawn from a 16x12 grid. Blinks now and then. */
class PixelCatView(ctx: Context, private val bodyColor: Int, private val seed: Int) : View(ctx) {

    companion object {
        // k = outline/eyes, w = fur, p = pink, . = empty
        private val OPEN = arrayOf(
            "..kk........kk..",
            ".kwwk......kwwk.",
            ".kwpwkkkkkkwpwk.",
            ".kwwwwwwwwwwwwk.",
            ".kwwwwwwwwwwwwk.",
            ".kwwkkwwwwkkwwk.",
            ".kwwkkwwwwkkwwk.",
            ".kwwwwwwwwwwwwk.",
            ".kwwwwwppwwwwwk.",
            ".kwwpwwkkwwpwwk.",
            "..kwwwwwwwwwwk..",
            "...kkkkkkkkkkk.."
        )
        private val BLINK = arrayOf(
            OPEN[0], OPEN[1], OPEN[2], OPEN[3], OPEN[4],
            ".kwwwwwwwwwwwwk.",
            ".kwwkkwwwwkkwwk.",
            OPEN[7], OPEN[8], OPEN[9], OPEN[10], OPEN[11]
        )
        private const val OUTLINE = 0xFF4A0F2F.toInt()
        private const val PINK = 0xFFFF7EB6.toInt()
    }

    private val paint = Paint().apply { isAntiAlias = false }
    private var tintColor = 0
    private var blink = false

    private val blinker = object : Runnable {
        override fun run() {
            blink = true; invalidate()
            postDelayed({
                blink = false; invalidate()
                postDelayed(this, 1500L + (seed * 437L) % 1800L)
            }, 160)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        postDelayed(blinker, 700L + seed * 350L)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(blinker)
        super.onDetachedFromWindow()
    }

    /** Override the fur color (used for the rainbow effect). 0 = back to normal. */
    fun tint(c: Int) { tintColor = c; invalidate() }

    override fun onDraw(canvas: Canvas) {
        val cell = minOf(width / 16, height / 12).coerceAtLeast(1)
        val ox = (width - cell * 16) / 2
        val oy = (height - cell * 12) / 2
        val fur = if (tintColor != 0) tintColor else bodyColor
        val rows = if (blink) BLINK else OPEN
        for (y in rows.indices) for (x in 0 until 16) {
            val color = when (rows[y][x]) {
                'k' -> OUTLINE
                'w' -> fur
                'p' -> PINK
                else -> continue
            }
            paint.color = color
            val l = ox + x * cell; val t = oy + y * cell
            canvas.drawRect(l.toFloat(), t.toFloat(), (l + cell).toFloat(), (t + cell).toFloat(), paint)
        }
    }
}
