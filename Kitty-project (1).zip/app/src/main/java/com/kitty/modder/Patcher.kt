package com.kitty.modder

import com.android.apksig.ApkSigner
import com.google.common.collect.ImmutableList
import com.google.common.collect.ImmutableSet
import org.jf.dexlib2.AccessFlags
import org.jf.dexlib2.DexFileFactory
import org.jf.dexlib2.Opcode
import org.jf.dexlib2.Opcodes
import org.jf.dexlib2.builder.MutableMethodImplementation
import org.jf.dexlib2.builder.instruction.BuilderInstruction10x
import org.jf.dexlib2.builder.instruction.BuilderInstruction21c
import org.jf.dexlib2.builder.instruction.BuilderInstruction35c
import org.jf.dexlib2.iface.Method
import org.jf.dexlib2.iface.MethodParameter
import org.jf.dexlib2.immutable.ImmutableClassDef
import org.jf.dexlib2.immutable.ImmutableDexFile
import org.jf.dexlib2.immutable.ImmutableMethod
import org.jf.dexlib2.immutable.reference.ImmutableMethodReference
import org.jf.dexlib2.immutable.reference.ImmutableStringReference
import org.jf.dexlib2.writer.io.FileDataStore
import org.jf.dexlib2.writer.pool.DexPool
import java.io.File
import java.io.FilterOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

object Patcher {

    private val UNITY_ACTIVITIES = setOf(
        "Lcom/unity3d/player/UnityPlayerActivity;",
        "Lcom/unity3d/player/UnityPlayerGameActivity;"
    )
    private val DEX_NAME = Regex("classes\\d*\\.dex")
    private const val KS_PASS = "kittykey"

    private class Counting(o: OutputStream) : FilterOutputStream(o) {
        var count = 0L
        override fun write(b: Int) { out.write(b); count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
    }

    /** Full pipeline. Returns the signed APK file (inside [work]). */
    fun patch(
        input: File, lib: File, entryName: String, patchDex: Boolean,
        work: File, keystore: InputStream, log: (String) -> Unit
    ): File {
        val libPath = "lib/arm64-v8a/$entryName"
        val loadName = entryName.removePrefix("lib").removeSuffix(".so")
        val replacements = HashMap<String, File>()

        ZipFile(input).use { zf ->
            if (zf.entries().asSequence().none { it.name.startsWith("lib/arm64-v8a/") })
                log("Warning: APK has no arm64-v8a libs. Quest needs arm64.")

            if (patchDex) {
                log("Looking for the Unity activity in the DEX files...")
                val dexNames = zf.entries().asSequence().map { it.name }
                    .filter { DEX_NAME.matches(it) }.sorted().toList()
                var done = false
                for (name in dexNames) {
                    val src = File(work, "src_$name")
                    zf.getInputStream(zf.getEntry(name)).use { i -> src.outputStream().use { o -> i.copyTo(o) } }
                    val dst = File(work, "patched_$name")
                    val cls = patchDex(src, dst, loadName)
                    src.delete()
                    if (cls != null) {
                        replacements[name] = dst
                        log("Patched $cls in $name (loads \"$loadName\")")
                        done = true
                        break
                    } else dst.delete()
                }
                if (!done) throw IllegalStateException(
                    "Couldn't find a Unity activity class to patch. Untick 'Patch DEX' if your lib loads itself."
                )
            }

            log("Rebuilding APK (this can take a few minutes)...")
            val aligned = File(work, "aligned.apk")
            writeAligned(zf, aligned, libPath, lib, replacements)
            log("Added $libPath")

            log("Signing...")
            val out = File(work, "signed.apk")
            sign(aligned, out, keystore)
            aligned.delete()
            return out
        }
    }

    // ---------- DEX ----------

    private fun patchDex(src: File, dst: File, loadName: String): String? {
        val opcodes = Opcodes.forApi(30)
        val dex = DexFileFactory.loadDexFile(src, opcodes)
        val classes = dex.classes.toList()
        val target = classes.firstOrNull { it.type in UNITY_ACTIVITIES }
            ?: classes.firstOrNull { it.superclass in UNITY_ACTIVITIES }
            ?: return null

        fun inject(impl: MutableMethodImplementation) {
            impl.addInstruction(0, BuilderInstruction21c(Opcode.CONST_STRING, 0, ImmutableStringReference(loadName)))
            impl.addInstruction(
                1, BuilderInstruction35c(
                    Opcode.INVOKE_STATIC, 1, 0, 0, 0, 0, 0,
                    ImmutableMethodReference(
                        "Ljava/lang/System;", "loadLibrary",
                        ImmutableList.of("Ljava/lang/String;"), "V"
                    )
                )
            )
        }

        fun freshClinit(): ImmutableMethod {
            val impl = MutableMethodImplementation(1)
            inject(impl)
            impl.addInstruction(2, BuilderInstruction10x(Opcode.RETURN_VOID))
            return ImmutableMethod(
                target.type, "<clinit>", ImmutableList.of<MethodParameter>(), "V",
                AccessFlags.STATIC.value or AccessFlags.CONSTRUCTOR.value,
                ImmutableSet.of(), ImmutableSet.of(), impl
            )
        }

        val direct = ArrayList<Method>()
        var found = false
        for (m in target.directMethods) {
            if (m.name == "<clinit>") {
                found = true
                val impl = m.implementation
                if (impl != null && impl.registerCount >= 1) {
                    val mi = MutableMethodImplementation(impl)
                    inject(mi)
                    direct.add(
                        ImmutableMethod(
                            m.definingClass, m.name, m.parameters, m.returnType, m.accessFlags,
                            m.annotations, m.hiddenApiRestrictions, mi
                        )
                    )
                } else direct.add(freshClinit())
            } else direct.add(m)
        }
        if (!found) direct.add(freshClinit())

        val newClass = ImmutableClassDef(
            target.type, target.accessFlags, target.superclass, target.interfaces,
            target.sourceFile, target.annotations, target.staticFields,
            target.instanceFields, direct, target.virtualMethods
        )
        val all = classes.map { if (it === target) newClass else it }
        DexPool.writeTo(FileDataStore(dst), ImmutableDexFile(opcodes, all))
        return target.type
    }

    // ---------- ZIP ----------

    private fun isSignature(n: String) = n.startsWith("META-INF/") &&
        (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC") || n.endsWith("MANIFEST.MF"))

    private fun padFor(zos: ZipOutputStream, c: Counting, ze: ZipEntry, alignment: Int) {
        zos.closeEntry() // flush previous entry so the byte count is exact
        val nameLen = ze.name.toByteArray(Charsets.UTF_8).size
        val offset = c.count + 30 + nameLen
        var pad = ((alignment - (offset % alignment)) % alignment).toInt()
        if (pad == 0) return
        if (pad < 4) pad += alignment
        val x = ByteArray(pad)
        x[0] = 0x35; x[1] = 0xD9.toByte()
        x[2] = ((pad - 4) and 0xff).toByte(); x[3] = (((pad - 4) shr 8) and 0xff).toByte()
        ze.extra = x
    }

    private fun crcOf(f: File): Long {
        val crc = CRC32(); val buf = ByteArray(1 shl 16)
        f.inputStream().use { i -> while (true) { val n = i.read(buf); if (n < 0) break; crc.update(buf, 0, n) } }
        return crc.value
    }

    private fun writeAligned(zf: ZipFile, dst: File, libPath: String, lib: File, repl: Map<String, File>) {
        val counting = Counting(dst.outputStream().buffered(1 shl 16))
        ZipOutputStream(counting).use { zos ->
            zos.setLevel(Deflater.BEST_SPEED)
            for (e in zf.entries()) {
                val n = e.name
                if (e.isDirectory || isSignature(n) || n == libPath) continue
                val replacement = repl[n]
                if (replacement != null) {
                    zos.closeEntry()
                    zos.putNextEntry(ZipEntry(n))
                    replacement.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                    continue
                }
                val ze = ZipEntry(n)
                if (e.method == ZipEntry.STORED) {
                    ze.method = ZipEntry.STORED
                    ze.size = e.size; ze.compressedSize = e.size; ze.crc = e.crc
                    padFor(zos, counting, ze, if (n.endsWith(".so")) 16384 else 4)
                } else {
                    zos.closeEntry()
                }
                zos.putNextEntry(ze)
                zf.getInputStream(e).use { it.copyTo(zos) }
                zos.closeEntry()
            }
            // the mod lib, stored + page-aligned so it works with or without extractNativeLibs
            val ze = ZipEntry(libPath)
            ze.method = ZipEntry.STORED
            ze.size = lib.length(); ze.compressedSize = lib.length(); ze.crc = crcOf(lib)
            padFor(zos, counting, ze, 16384)
            zos.putNextEntry(ze)
            lib.inputStream().use { it.copyTo(zos) }
            zos.closeEntry()
        }
    }

    // ---------- SIGN ----------

    private fun sign(inApk: File, outApk: File, keystore: InputStream) {
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(keystore, KS_PASS.toCharArray())
        val alias = ks.aliases().nextElement()
        val key = ks.getKey(alias, KS_PASS.toCharArray()) as PrivateKey
        val cert = ks.getCertificate(alias) as X509Certificate
        val cfg = ApkSigner.SignerConfig.Builder("kitty", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(inApk).setOutputApk(outApk)
            .setMinSdkVersion(24)
            .setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(true)
            .build().sign()
    }
}
