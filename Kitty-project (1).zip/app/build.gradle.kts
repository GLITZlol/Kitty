plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kitty.modder"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.kitty.modder"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += setOf("META-INF/**", "**/*.kotlin_module") } }
}

dependencies {
    implementation("org.smali:dexlib2:2.5.2") { exclude(group = "com.google.guava") }
    implementation("com.google.guava:guava:32.1.3-android")
    implementation("com.android.tools.build:apksig:8.5.2")
}
